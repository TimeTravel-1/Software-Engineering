Name: J. Daniel Gonzalez
UCID: 10058656

For the assignment 1 models, I chose to model the provided assignment 1 solution.