Name: 	J. Daniel Gonzalez
UCID:	10058656
Class:	SENG 301
Ass:		3
 
Description: Assignment 2 solution without a VendingMachineFactory and without the entire Parser package, 
as well as including tests corresponding to each one of the ass2 test scripts (minus U01, because it 
doesn't make sense to test hardware that doesn't exist).

All assignment requirements as described on D2L have been completed to the best of my knowledge.